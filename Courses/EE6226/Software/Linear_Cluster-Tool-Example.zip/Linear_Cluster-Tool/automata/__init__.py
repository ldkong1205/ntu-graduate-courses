#
# $Id: __init__.py 747 2010-05-20 14:37:38Z hat $
#
"""
Susyna
======
Python package for SUpervisor SYnthesis for Nondeterministic Automata (SUSYNA).

@todo: Write down what exists in the package and how to use it.
"""

version = "0.4.3dev"
installed = False
