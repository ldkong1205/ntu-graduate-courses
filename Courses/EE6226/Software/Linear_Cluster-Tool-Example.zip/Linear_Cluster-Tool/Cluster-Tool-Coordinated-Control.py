# For N link automated supervisor design
from automata import frontend

## Compute local supervisor for each link

# link1
frontend.make_product('C_in.cfg, C_out.cfg, Proc_11.cfg, Proc_12.cfg, R1.cfg, B1.cfg', 'Plant1.cfg')

frontend.make_product('H11.cfg, H12.cfg, H13.cfg, H14.cfg', 'Spec1.cfg')

frontend.make_supervisor('Plant1.cfg', 'Spec1.cfg', 'Supervisor1.cfg')

#frontend.make_sequential_abstraction('superlink1.cfg', 'tau, pick_10, place_10, pick_13, place_13, pick_20, place_20', 'superlink1ab.cfg')


# link2
frontend.make_product('Proc_21.cfg, Proc_22.cfg, R2.cfg, B1.cfg, B2.cfg', 'Plant2.cfg')

frontend.make_product('H21.cfg, H22.cfg, H23.cfg, H24.cfg', 'Spec2.cfg')

frontend.make_supervisor('Plant2.cfg', 'Spec2.cfg', 'Supervisor2.cfg')


# link3
frontend.make_product('Proc_31.cfg, Proc_32.cfg, R3.cfg, B2.cfg, B3.cfg', 'Plant3.cfg')

frontend.make_product('H31.cfg, H32.cfg, H33.cfg, H34.cfg', 'Spec3.cfg')

frontend.make_supervisor('Plant3.cfg', 'Spec3.cfg', 'Supervisor3.cfg')

# link4
frontend.make_product('Proc_41.cfg, Proc_42.cfg, Proc_43.cfg, R4.cfg, B3.cfg', 'Plant4.cfg')

frontend.make_product('H41.cfg, H42.cfg, H43.cfg, H44.cfg', 'Spec4.cfg')

frontend.make_supervisor('Plant4.cfg', 'Spec4.cfg', 'Supervisor4.cfg')


## Compute local coordinators

# Compute local coordinator for link1 and link2
frontend.make_sequential_abstraction('supervisor1.cfg', 'tau, mu, R1-pick-C, R1-drop-C, R1-drop-B1, R1-pick-B1, R2-drop-B1, R2-pick-B1', 'link1-abstraction.cfg')

frontend.make_sequential_abstraction('supervisor2.cfg', 'tau, mu, R1-drop-B1, R1-pick-B1, R2-drop-B1, R2-pick-B1, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2', 'link2-abstraction.cfg')

frontend.make_product('link1-abstraction.cfg, link2-abstraction.cfg', 'link12.cfg')

# create a nominal specification Spec12.cfg
frontend.make_supervisor('link12.cfg', 'Spec12.cfg', 'Coordinator12.cfg')

# Compute local coordinator for link3 and link4
frontend.make_sequential_abstraction('supervisor3.cfg', 'tau, mu, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2, R4-drop-B3, R4-pick-B3, R3-drop-B3, R3-pick-B3 ', 'link3-abstraction.cfg')

frontend.make_sequential_abstraction('supervisor4.cfg', 'tau, mu, R4-drop-B3, R4-pick-B3, R3-drop-B3, R3-pick-B3', 'link4-abstraction.cfg')

frontend.make_product('link3-abstraction.cfg, link4-abstraction.cfg', 'link34.cfg')

# create a nominal specification Spec12.cfg
frontend.make_supervisor('link34.cfg', 'Spec34.cfg', 'Coordinator34.cfg')


# Compute local coordinator for link 1, link2, link3 and link4

frontend.make_sequential_abstraction('supervisor1.cfg, supervisor2.cfg, Coordinator12.cfg', 'tau, mu, R1-pick-C, R1-drop-C, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2', 'link12-abstraction.cfg')

frontend.make_sequential_abstraction('supervisor3.cfg, supervisor4.cfg, Coordinator34.cfg', 'tau, mu, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2', 'link34-abstraction.cfg')

frontend.make_product('link12-abstraction.cfg, link34-abstraction.cfg', 'link1234.cfg')

# create a nominal specification Spec12.cfg
frontend.make_supervisor('link1234.cfg', 'Spec1234.cfg', 'Coordinator1234.cfg')


## Check nonconflictingness 
#frontend.make_nonconflicting_check('supervisor1.cfg, supervisor2.cfg, supervisor3.cfg, supervisor4.cfg, Coordinator12.cfg, Coordinator34.cfg, Coordinator1234.cfg','true')











#### Language-based distributed synthesis ##########

## Compute local coordinators

# Compute local coordinator for link1 and link2
frontend.make_sequential_abstraction('supervisor1.cfg', 'tau, mu, R1-pick-C, R1-drop-C, R1-drop-B1, R1-pick-B1, R2-drop-B1, R2-pick-B1,R1-pick-P11, R1-pick-P12', 'link1-abstraction-lan.cfg')

frontend.make_sequential_abstraction('supervisor2.cfg', 'tau, mu, R1-drop-B1, R1-pick-B1, R2-drop-B1, R2-pick-B1, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2, R2-pick-P21, R2-pick-P22', 'link2-abstraction-lan.cfg')

frontend.make_product('link1-abstraction-lan.cfg, link2-abstraction-lan.cfg', 'link12-lan.cfg')

# create a nominal specification Spec12.cfg
frontend.make_supervisor('link12-lan.cfg', 'Spec12.cfg', 'Coordinator12-lan.cfg')

# Compute local coordinator for link3 and link4
frontend.make_sequential_abstraction('supervisor3.cfg', 'tau, mu, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2, R4-drop-B3, R4-pick-B3, R3-drop-B3, R3-pick-B3, R3-pick-P31, R3-pick-P32', 'link3-abstraction-lan.cfg')

frontend.make_sequential_abstraction('supervisor4.cfg', 'tau, mu, R4-drop-B3, R4-pick-B3, R3-drop-B3, R3-pick-B3, R4-pick-P43', 'link4-abstraction-lan.cfg')

frontend.make_product('link3-abstraction-lan.cfg, link4-abstraction-lan.cfg', 'link34-lan.cfg')

# create a nominal specification Spec12.cfg
frontend.make_supervisor('link34-lan.cfg', 'Spec34.cfg', 'Coordinator34-lan.cfg')


# Compute local coordinator for link 1, link2, link3 and link4

frontend.make_sequential_abstraction('supervisor1.cfg, supervisor2.cfg, Coordinator12-lan.cfg', 'tau, mu, R1-pick-C, R1-drop-C, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2, R1-pick-P11, R1-pick-P12, R2-pick-P21, R2-pick-P22', 'link12-abstraction-lan.cfg')

frontend.make_sequential_abstraction('supervisor3.cfg, supervisor4.cfg, Coordinator34-lan.cfg', 'tau, mu, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2, R3-pick-P31, R3-pick-P32, R4-pick-P43', 'link34-abstraction-lan.cfg')

frontend.make_product('link12-abstraction-lan.cfg, link34-abstraction-lan.cfg', 'link1234-lan.cfg')

# create a nominal specification Spec12.cfg
frontend.make_supervisor('link1234-lan.cfg', 'Spec1234.cfg', 'Coordinator1234-lan.cfg')


## Check nonconflictingness 
#frontend.make_nonconflicting_check('supervisor1.cfg, supervisor2.cfg, supervisor3.cfg, supervisor4.cfg, Coordinator12-lan.cfg, Coordinator34-lan.cfg, Coordinator1234-lan.cfg','true')



## Check maximum permissiveness of supervisor1xSupervisor2xCoordinator12
frontend.make_sequential_abstraction('supervisor1.cfg', 'tau, mu, R1-pick-P11', 'nlink1-abstraction.cfg')

frontend.make_sequential_abstraction('supervisor2.cfg', 'tau, mu, R2-pick-P22, R3-drop-B2', 'nlink2-abstraction.cfg')

frontend.make_product('nlink1-abstraction.cfg, nlink2-abstraction.cfg', 'nlink12.cfg')

# create a nominal specification Spec12.cfg
frontend.make_supervisor('nlink12.cfg', 'Spec12.cfg', 'nCoordinator12.cfg')


frontend.make_product('supervisor1.cfg, supervisor2.cfg, nCoordinator12.cfg', 'distributed12.cfg')

frontend.make_product('Plant1.cfg, Plant2.cfg', 'Plant12.cfg')

frontend.make_product('Spec1.cfg, Spec2.cfg', 'Requirement12.cfg')

frontend.make_supervisor('Plant12.cfg', 'Requirement12.cfg', 'CentralSuper12.cfg')

frontend.make_language_equivalence_test('distributed12.cfg','CentralSuper12.cfg')


## Check maximum permissiveness of distributed supervisor by using observers
frontend.make_observer_check('supervisor1.cfg', 'tau, mu, R1-pick-P11, R1-pick-C')

frontend.make_observer_check('supervisor2.cfg', 'tau, mu, R2-pick-P22, R3-drop-B2')

frontend.make_sequential_abstraction('supervisor1.cfg', 'tau, mu, R1-pick-P11, R1-pick-C', 'nnlink1-abstraction.cfg')

frontend.make_sequential_abstraction('supervisor2.cfg', 'tau, mu, R2-pick-P22, R3-drop-B2', 'nnlink2-abstraction.cfg')

frontend.make_product('nnlink1-abstraction.cfg, nnlink2-abstraction.cfg', 'nnlink12.cfg')

# create a nominal specification Spec12.cfg
frontend.make_supervisor('nnlink12.cfg', 'Spec12.cfg', 'nnCoordinator12.cfg')


frontend.make_product('supervisor1.cfg, supervisor2.cfg, nnCoordinator12.cfg', 'observer-distributed12.cfg')

frontend.make_language_equivalence_test('observer-distributed12.cfg','CentralSuper12.cfg')


# tests for observers
#frontend.make_observer_check('supervisor1.cfg', 'tau, mu, R1-pick-C, R1-drop-C, R1-drop-B1, R1-pick-B1, R2-drop-B1, R2-pick-B1')
#frontend.make_observer_check('supervisor2.cfg', 'tau, mu, R1-drop-B1, R1-pick-B1, R2-drop-B1, R2-pick-B1, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2')
#frontend.make_observer_check('supervisor3.cfg', 'tau, mu, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2, R4-drop-B3, R4-pick-B3, R3-drop-B3, R3-pick-B3 ')
#frontend.make_observer_check('supervisor4.cfg', 'tau, mu, R4-drop-B3, R4-pick-B3, R3-drop-B3, R3-pick-B3')


#frontend.make_product('supervisor1.cfg, supervisor2.cfg, Coordinator12.cfg', 'test12.cfg')
#frontend.make_product('supervisor3.cfg, supervisor4.cfg, Coordinator34.cfg', 'test34.cfg')
#frontend.make_observer_check('test12.cfg', 'tau, mu, R1-pick-C, R1-drop-C, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2')
#frontend.make_observer_check('test34.cfg', 'tau, mu, R2-drop-B2, R2-pick-B2, R3-drop-B2, R3-pick-B2')  
