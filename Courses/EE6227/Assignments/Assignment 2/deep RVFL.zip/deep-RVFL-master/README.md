# deep-RVFL
Deep Random Vector Functional Link training function
